// This is just a very simple API route that throws an example error.
// Feel free to delete this file and the entire sentry route.

export const GET = async () => {
	// Comment to check sentry works normally in CI - 3
	throw new Error('Sentry Example API Route Error');
};
